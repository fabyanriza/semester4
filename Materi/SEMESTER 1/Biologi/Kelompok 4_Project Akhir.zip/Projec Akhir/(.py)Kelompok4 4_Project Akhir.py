
def Program1():
    print("Lose Weight & Still Fit (30 days)")
    print("Istirahat 30 detik di setiap pergantian gerakan")
    yy = "Yes"
    while(yy=="Yes" or yy=="YES" or yy=="yes"):
        a = int(input("Hari ke\t: "))
        if (a==1):
            print("1. Mountain Climber(30 seconds)\n2. Squats(16 times)\n3. High Stepping(30 seconds\n4. Push Ups(5 times)\n5. Reverse Crunches(16 times)\n6. Plank(15 seconds)\n7. Cobra Stretch(30 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif (a==2):
            print("1. Mountain Climber(30 seconds)\n2. Triceps Dips(16 times)\n3. Jumping Jacks(30 seconds)\n4. Long Arm Crunches(16 times)\n5. Bicycle Crunches(16 times)\n6. Plank(15 Seconds)\n7. Cobra Stretch(30 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif (a==3):
            print("1. Mountain Climber(30 seconds)\n2. Jumping Jacks(30 seconds)\n3. Abdominal Crunches(16 times)\n4. Heel Touch(16 times)\n5. Flutter Kicks(30 seconds))\n6. Plank(15 Seconds)\n7. Cobra Stretch(30 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==4):
            print("Rest Day\n")
            xx = input("Apakah anda telah beristirahat dengan baik hari ini(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, konsisten dalam berolahraga dan berisitrahat adalah sebuah usaha yang patut diapresiasi\n")
            else:
                print("Untuk mendapatkan hasil yang maksimal, istirahat yang cukup sangat diperlukan :)")
        elif(a==5):
            print("1. Skipping Without Rope(30 seconds)\n2. Lunges(16 times)\n3. Push Ups(5 times)\n4. Reverse Crunches(16 times)\n5. Heel Touch(16 times)\n6. Plank(15 Seconds)\n7. Cobra Stretch(30 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==6):
            print("1. Skipping Without Rope(30 seconds)\n2. Triceps Dips(16 times)\n3. High Stepping(30 seconds)\n4. Squat Pulses(16 times)\n5. Bicycle Crunches(16 times)\n6. Plank(15 Seconds)\n7. Cobra Stretch(30 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==7):
            print("1. Skipping Without Rope(30 seconds)\n2. Triceps Dips(16 times)\n3. Lunges(16 times)\n4. Long Arm Crunches(16 times)\n5. Reverse Crunches(16 times)\n6. Plank(15 Seconds)\n7. Cobra Stretch(30 seconds\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==8):
            print("Rest Day\n")
            xx = input("Apakah anda telah beristirahat dengan baik hari ini(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, konsisten dalam berolahraga dan berisitrahat adalah sebuah usaha yang patut diapresiasi\n")
            else:
                print("Untuk mendapatkan hasil yang maksimal, istirahat yang cukup sangat diperlukan :)")
        elif(a==9):
            print("1. Mountain Climber(30 seconds)\n2. Squats(16 times)\n3. Plank Jacks(30 seconds)\n4. Push Ups(7 times)\n5. Leg Raises(16 times)\n6. Heel touch(16 times)\n7. Plank(20 Seconds)\n8. Cobra Stretch(30 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==10):
            print("1. Mountain Climber(30 seconds)\n2. Lunges(18 times)\n3. Plank Jacks(30 seconds)\n4. Long Arm Crunches(16 times)\n5. Abdominal Crunches(16 times)\n6. Reverse Crunches\n7. Plank(20 Seconds)\n8. Cobra Stretch(30 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==11):
            print("1. Mountain Climber(30 seconds)\n2. Squats(16 times)\n3. Lateral Plank Walk(30 seconds)\n4. Push Ups(7 times)\n5. Bicycle Crunches(18 times)\n6. Heel touch(18 times)\n7. Plank(20 Seconds)\n8. Cobra Stretch(30 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==12):
            print("Rest Day\n")
            xx = input("Apakah anda telah beristirahat dengan baik hari ini(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, konsisten dalam berolahraga dan berisitrahat adalah sebuah usaha yang patut diapresiasi\n")
            else:
                print("Untuk mendapatkan hasil yang maksimal, istirahat yang cukup sangat diperlukan :)")
        elif(a==13):
            print("1. Skipping Without Rope(30 seconds)\n2. Triceps Dips(16 times)\n3. High Stepping(36 seconds)\n4. Lateral Plank Walk(30 seconds)\n5. Long Arm Crunches(16 times)\n6. Abdominal Crunches(16 times)\n7. Plank(20 Seconds)\n8. Cobra Stretch(30 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==14):
            print("1. Skipping Without Rope(30 seconds)\n2. Jumping Jacks(30 seconds)\n3. Step Up Onto Chair(16 times)\n4. Leg Raises(16 times)\n5. Butt Bridge(18 times)\n6. Bicycle Crunches\n7. Plank(20 Seconds)\n8. Cobra Stretch(30 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==15):
            print("1. Skipping Without Rope(30 seconds)\n2. Step Up Onto Chair(18 times)\n3. Push Ups(7 seconds)\n4. Leg Raises(18 times)\n5. Heel Touch(18 times)\n6. Reclined Oblique Twist(16 times)\n7. Plank(25 Seconds)\n8. Cobra Stretch(30 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==16):
            print("Rest Day\n")
            xx = input("Apakah anda telah beristirahat dengan baik hari ini(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, konsisten dalam berolahraga dan berisitrahat adalah sebuah usaha yang patut diapresiasi\n")
            else:
                print("Untuk mendapatkan hasil yang maksimal, istirahat yang cukup sangat diperlukan :)")
        elif(a==17):
            print("1. Mountain Climber(30 seconds)\n2. Lunges(18 times)\n3. Plank Jacks(30 seconds)\n4. Abdominal Crunches(18 times)\n5. Butt Bridge(16 times)\n6. Reverse Crunches(18 times)\n7. Reclined Oblique Twist(16 times)\n8. Plank(25 Seconds)\n9. Cobra Stretch(30 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==18):
            print("1. Mountain Climber(30 seconds)\n2. Squats(16 times)\n3. Burpees(6 times)\n4. Push Ups(8 times)\n5. Reverse Crunches(18 times)\n6. Heel Touch(18 times)\n7. Flutter Kickcs(30 seconds)\n8. Plank(25 Seconds)\n9. Cobra Stretch(30 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==19):
            print("1. Mountain Climber(30 seconds)\n2. High Stepping(36 seconds)\n3. Lateral Plank Walk(40 seconds)\n4. Squat Pulses(30 seconds)\n5. Abdominal Crunches(18 times)\n6. Butt Bridge(16 times)\n7. Reclined Oblique Twist(16 times)\n8. Plank(25 Seconds)\n9. Cobra Stretch(30 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==20):
            print("Rest Day\n")
            xx = input("Apakah anda telah beristirahat dengan baik hari ini(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, konsisten dalam berolahraga dan berisitrahat adalah sebuah usaha yang patut diapresiasi\n")
            else:
                print("Untuk mendapatkan hasil yang maksimal, istirahat yang cukup sangat diperlukan :)")
        elif(a==21):
            print("1. Skipping Without Rope(30 seconds)\n2. Triceps Dips(16 times)\n3. Burpees(6 times)\n4. Long Arm Crunches(16 times)\n5. Butt Bridge(20 times)\n6. Flutter Kicks(30 seconds)\n7. Reclined Oblique Twist(16 seconds)\n8. Plank(25 Seconds)\n9. Cobra Stretch(30 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==22):
            print("1. Skipping Without Rope(30 seconds)\n2. Squats(18 times))\n3. Triceps Dips(18 times)\n4. Plank Jacks(40 seconds)\n5. Leg Raises(18 times)\n6. Heel Touch(20 times)\n7. Flutter Kicks(30 seconds)\n8. Plank(25 Seconds)\n9. Cobra Stretch(30 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==23):
            print("1. Skipping Without Rope(30 seconds)\n2. Lunges(20 times)\n3. Plank Jacks(40 seconds)\n4. Abdominal Crunches(20 times)\n5. Bicycle Crunches(20 times)\n6. Reverse Crunches(30 seconds)\n7. Crunches With Legs Raised(16 times)\n8. Plank(25 Seconds)\n9. Cobra Stretch(30 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==24):
            print("Rest Day\n")
            xx = input("Apakah anda telah beristirahat dengan baik hari ini(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, konsisten dalam berolahraga dan berisitrahat adalah sebuah usaha yang patut diapresiasi\n")
            else:
                print("Untuk mendapatkan hasil yang maksimal, istirahat yang cukup sangat diperlukan :)")
        elif(a==25):
            print("1. Mountain Climber(30 seconds)\n2. Triceps Dips(18 times)\n3. High Stepping(40 secondss)\n4. Long Arm Crunches(18 times)\n5. Butt Bridge(20 times)\n6. Flutter Kicks(30 seconds)\n7. Reclined Oblique Twist(16 times)\n8. Plank(30 Seconds)\n9. Cobra Stretch(30 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==26):
            print("1. Mountain Climber(30 seconds)\n2. Lunges(20 times)\n3. Jumping Jacks(40 seconds)\n4. Step Up Onto Chair(20times)\n5. Push Ups(8 times)\n6. Long Arm Crunches(20 times)\n7. Reclined Oblique Twist(18 times)\n8. Plank(30 Seconds)\n9. Cobra Stretch(30 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==27):
            print("1. Mountain Climber(30 seconds)\n2. Squats(18 times)\n3. Plank Jacks(40 seconds)\n4. Burpees(6 times)\n5. Reverse Crunches(20 times)\n6. Heel Touch(20 seconds)\n7. Crunches With Legs Raised(18 times)\n8. Plank(30 Seconds)\n9. Cobra Stretch(30 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==28):
            print("Rest Day\n")
            xx = input("Apakah anda telah beristirahat dengan baik hari ini(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, konsisten dalam berolahraga dan berisitrahat adalah sebuah usaha yang patut diapresiasi\n")
            else:
                print("Untuk mendapatkan hasil yang maksimal, istirahat yang cukup sangat diperlukan :)")
        elif(a==29):
            print("1. Skipping Without Rope(30 seconds)\n2. Squats(20 times)\n3. Triceps Dips(20 times)\n4. Jumping Jacks(40 seconds)\n5. Squat Pulses(30 seconds)\n6. Long Arm Crunches(20 times)\n7. Flutter Kicks(30 seconds)\n8. Plank(30 Seconds)\n9. Cobra Stretch(30 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==30):
            print("1. Skipping Without Rope(30 seconds)\n2. Lunges(20 times)\n3. Jumping Jacks(40 seconds)\n4. Lateral Plank Walk(30 seconds)\n5. Push Ups(10 times)\n6. Abdominal Crunches\n7. Heel Touch(20 times)\n8. Plank(20 Seconds)\n9. Cobra Stretch(30 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
                print("\nSelamat, anda telah menyelesaikan program 30 hari untuk menurunkan berat badan\n")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
                print("\nSelamat, anda telah menyelesaikan program 30 hari untuk menurunkan berat badan\n")
        yy = str(input("\nApakah anda ingin melanjutkan lagi(Yes/No)\t: "))
        if (yy == "Yes" or yy=="YES" or yy=="yes"):
            continue
        elif(yy == "No" or yy=="no" or yy=="NO"):
            break
        else:
            break
    

def Program2():
    print("Lost Belly Fat(30 days)")
    print("Istirahat 30 detik di setiap pergantian gerakan")
    yy = "Yes"
    while(yy=="Yes" or yy=="YES" or yy=="yes"):
        a = int(input("Hari ke\t: "))
        if (a==1):
            print("1. High Stepping(20 seconds)\n2. Jumping Jacks(30 seconds)\n3. Standing Bicycles Crunches(22 times)\n4. Mountain Climber(20 times)\n5. Abdominal Crunches(12 times)\n6. Russian Twist(16 times)\n7. Plank(30 seconds)\n8. Standing Bicycles Crunches(22 times)\n9. Mountain Climber(20 times)\n10. Abdominal Crunches(12 times)\n11. Heel Touch\n12. Plank (30 seconds)\n13. Cobra Stretch(20 seconds)\n14. Lying Twist Stretch Left(20 seconds)\n15. Lying Twist Stretch right(20 seconds)")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif (a==2):
            print("1. High Stepping(20 seconds)\n2. Jumping Jacks(30 seconds)\n3. Sit Ups(6 times)\n4. Russian Twist(16 times)\n5. 90/90 crunch(10 times)\n6. Leg In & Outs(6 times)\n7. Butt Bridge(16 times)\n8. Sit Ups(6 times)\n9. Russian Twist(16 times)\n10. 90/90 crunch(10 times)\n11. Leg In & Outs(6 times)\n12. Butt Bridge(16 times)\n13. Cobra Stretch(20 seconds)\n14. Lying Twist Stretch Left(20 seconds)\n15. Lying Twist Stretch right(20 seconds)")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif (a==3):
            print("1. High Stepping(20 seconds)\n2. Jumping Jacks(30 seconds)\n3. Mountain Climber(22 times)\n4. Abdominal Crunches(12 times)\n5. Leg In & Outs(8 times)\n6. Plank (30 seconds)\n7. Reclined Oblique Test(10 times)\n8. Mountain Climber(22 times)\n9. Abdominal Crunches(12 times)\n10. Leg In & Outs(8 times)\n11. Plank (30 seconds)\n12. Reclined Oblique Test(10 times)\n13. Cobra Stretch(20 seconds)\n14. Lying Twist Stretch Left(20 seconds)\n15. Lying Twist Stretch right(20 seconds)")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==4):
            print("Rest Day\n")
            xx = input("Apakah anda telah beristirahat dengan baik hari ini(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, konsisten dalam berolahraga dan berisitrahat adalah sebuah usaha yang patut diapresiasi\n")
            else:
                print("Untuk mendapatkan hasil yang maksimal, istirahat yang cukup sangat diperlukan :)")
        elif(a==5):
            print("1. High Stepping(20 seconds)\n2. Jumping Jacks(30 seconds)\n3. Sit Ups(8 times)\n4. Russian Twist(16 times)\n5. Leg In & Outs(8 times)\n6. Butt bridge(16 times)\n7. Bicycle Crunches(10 times)\n8. Crossover Crunch(6 times)\n9. Sit Ups(8 times)\n10. Heel Touch(16 times)\n11. Leg In & Outs(8 times)\n12. Butt Bridge(16 times)\n13. Bicycle Crunches(10 seconds)\n14. Dead Bug(6 times)\n15. Cobra Stretch(30 seconds)\n16. Lying Twist Stretch Left(30 seconds)\n17. Lying Twist Stretch right(30 seconds)")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==6):
            print("1. High Stepping(20 seconds)\n2. Jumping Jacks(30 seconds)\n3. Mountain Climber(22 times)\n4. Abdominal Crunches(12 times)\n5. Russian Twist(16 times)\n6. 90/90 Crunch(10 times)\n7. Crossover Crunch(8 times)\n8. Mountain Climber(22 times)\n9. Abdominal Crunches(12 times)\n10. Russian Twist(16 times)\n11. 90/90 Crunch(10 times)\n12. Dead Bug(8 times)\n13. Cobra Stretch(30 seconds)\n14. Lying Twist Stretch Left(30 seconds)\n15. Lying Twist Stretch right(30 seconds)")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==7):
            print("1. High Stepping(20 seconds)\n2. Jumping Jacks(30 seconds)\n3. Standing Bicycle Crunches(22 times)\n4. Abdominal Crunches(14 times)\n5. Russian Twist(16 times)\n6. Side Bridges Right(6 times)\n7. Side Bridges Left(6 times)\n8. Standing Bicycle Crunches(22 times)\n9. Abdominal Crunches(14 times)\n10. Heel Touch(16 times)\n11. Side Bridges Right(6 times)\n12. Side Bridges Left(6 times)\n13. Cobra Stretch(30 seconds)\n14. Lying Twist Stretch Left(30 seconds)\n15. Lying Twist Stretch right(30 seconds)")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==8):
            xx = input("Apakah anda telah beristirahat dengan baik hari ini(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, konsisten dalam berolahraga dan berisitrahat adalah sebuah usaha yang patut diapresiasi\n")
            else:
                print("Untuk mendapatkan hasil yang maksimal, istirahat yang cukup sangat diperlukan :)")
        elif(a==9):
            print("1. High Stepping(20 seconds)\n2. Jumping Jacks(30 seconds)\n3. Mountain Climber(26 times)\n4. Sit Ups(8 times)\n5. Leg In & Outs(10 times)\n6. Plank(30 seconds)\n7. Reclined Oblique Twist(14 times)\n8. Crossover Crunch(8 times)\n9. Mountain Climber(26 times)\n10. Sit Ups(8 times)\n11. Leg In & Outs(10 times)\n12. Plank(30 seconds)\n13. Reclined Oblique Twist(14 times)\n14. Crossover Crunch(8 times)\n15. Cobra Stretch(30 seconds)\n16. Lying Twist Stretch Left(30 seconds)\n17. Lying Twist Stretch right(30 seconds)")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==10):
            print("1. High Stepping(20 seconds)\n2. Jumping Jacks(30 seconds)\n3. Abdominal Crunches(14 times)\n4. Russian Twist(18 times)\n5. 90/90 Crunch(12 times)\n6. Flutter Kicks(26 seconds)\n7. Bicycle Crunches(10 times)\n8. Abdominal Crunches(14 times)\n9. Russian Twist(18 times)\n10. 90/90 Crunch(12 times)\n11. Flutter Kicks(26 seconds)\n12. Bicycle Crunches(10 times)\n13. Cobra Stretch(30 seconds)\n14. Lying Twist Stretch Left(30 seconds)\n15. Lying Twist Stretch right(30 seconds)")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==11):
            print("1. High Stepping(20 seconds)\n2. Jumping Jacks(30 seconds)\n3. Mountain Climber(26 times)\n4. Sit Ups(8 times)\n5. Flutter Kicks(26 seconds)\n6. Side Bridges Right(10 times)\n7. Side Bridges Left(10 times)\n8. Bicycle Crunches(10 times)\n9. Mountain Climber(26 times)\n10. Sit Ups(8 times)\n11. Flutter Kicks(26 seconds)\n12. Side Bridges Right(10 times)\n13. Side Bridges Left(10 times)\n14. Bicycle Crunches(10 times)\n15. Cobra Stretch(30 seconds)\n16. Lying Twist Stretch Left(30 seconds)\n17. Lying Twist Stretch right(30 seconds)")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==12):
            xx = input("Apakah anda telah beristirahat dengan baik hari ini(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, konsisten dalam berolahraga dan berisitrahat adalah sebuah usaha yang patut diapresiasi\n")
            else:
                print("Untuk mendapatkan hasil yang maksimal, istirahat yang cukup sangat diperlukan :)")
        elif(a==13):
            print("1. High Stepping(20 seconds)\n2. Jumping Jacks(30 seconds)\n3. Standing Bicycle Crunches(24 times)\n4. Mountain Climber(26 times)\n5. Russian Twist(20 times)\n6. Plank(36 seconds)\n7. Side Bridges Right(10 times)\n8. Side Bridges Left(10 times)\n9. Standing Bicycle Crunches(24 times)\n10. Mountain Climber(26 times)\n11. Russian Twist(20 times)\n12. Plank(36 seconds)\n13. Side Bridges Right(10 times)\n14. Side Bridges Left(10 times)\n15. Cobra Stretch(30 seconds)\n16. Lying Twist Stretch Left(30 seconds)\n17. Lying Twist Stretch right(30 seconds)") 
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==14):
            print("1. High Stepping(20 seconds)\n2. Jumping Jacks(30 seconds)\n3. Abdominal Crunches(14 times)\n4. Russian Twist(20 times)\n5. 90/90 Crunch(12 times)\n6. Leg In & Outs(10 times)\n7. Flutter Kicks(26 seconds)\n8. Reclined Oblique Twist(16 times)\n9. Bicycle Crunches(12 times)\n10. Abdominal Crunches(14 times)\n11. Russian Twist(20 times)\n12. 90/90 Crunch(12 times)\n13. Leg In & Outs(10 times)\n14. Flutter Kicks(26 seconds)\n15. Reclined Oblique Twist(16 times)\n16. Bicycle Crunches(12 times)\n17. Cobra Stretch(30 seconds)\n18. Lying Twist Stretch Left(30 seconds)\n19. Lying Twist Stretch right(30 seconds)") 
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==15):
            print("1. High Stepping(20 seconds)\n2. Jumping Jacks(30 seconds)\n3. Mountain Climber (28 times)\n4. Abdominal Crunches (16 times)\n5. Leg In & Outs(12 times)\n6. Plank(40 seconds)\n7. Side Bridges Right(10 times)\n8. Side Bridges Left(10 times)\n9. Crossover Crunch(12 times)\n10. Mountain Climber (28 times)\n11. Abdominal Crunches (16 times)\n12. Leg In & Outs(12 times)\n13. Plank(40 seconds)\n14. Side Bridges Right(10 times)\n15. Side Bridges Left(10 times)\n16. Crossover Crunch(12 times)\n17. T Plank Left(4 times)\n18. T Plank Right(4 times)\n19. Cobra Stretch(30 seconds)\n20. Lying Twist Stretch Left(30 seconds)\n21. Lying Twist Stretch right(30 seconds)") 
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==16):
            print("Rest Day\n")
            xx = input("Apakah anda telah beristirahat dengan baik hari ini(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, konsisten dalam berolahraga dan berisitrahat adalah sebuah usaha yang patut diapresiasi\n")
            else:
                print("Untuk mendapatkan hasil yang maksimal, istirahat yang cukup sangat diperlukan :)")
        elif(a==17):
            print("1. High Stepping(20 seconds)\n2. Jumping Jacks(30 seconds)\n3. Mountain Climber(28 times)\n4. Sit Ups(12 times)\n5. Flutter Kicks (26 seconds)\n6. Reclined Oblique Twist(18 times)\n7. Side Bridges Right(10 times)\n8. Side Bridges Left(10 times)\n9. Bicycle Crunches(12 times)\n10. Mountain Climber(28 times)\n11. Sit Ups(12 times)\n12. Flutter Kicks (26 seconds)\n13. Reclined Oblique Twist(18 times)\n14. Side Bridges Right(10 times)\n15. Side Bridges Left(10 times)\n16. Bicycle Crunches(12 times)\n17. Cobra Stretch(30 seconds)\n18. Lying Twist Stretch Left(30 seconds)\n19. Lying Twist Stretch right(30 seconds)") 
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==18):
            print("1. High Stepping(20 seconds)\n2. Jumping Jacks(30 seconds)\n3. Abdominal Crunches(18 times)\n4. Russian Twist(22 times)\n5. 90/90 Crunch(14 times)\n6. Plank(40 seconds)\n7. Reclined Oblique Twist(18 times)\n8. Bicycle Crunches(14 times)\n9. Abdominal Crunches(18 times)\n10. Russian Twist(22 times)\n11. 90/90 Crunch(14 times)\n12. Plank(40 seconds)\n13. Reclined Oblique Twist(18 times)\n14. Bicycle Crunches(14 times)\n15. Side Plank Right(20 seconds)\n16. Side Plank Left(20 seconds)\n17. Cobra Stretch(30 seconds)\n18. Lying Twist Stretch Left(30 seconds)\n19. Lying Twist Stretch right(30 seconds)") 
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==19):
            print("1. High Stepping(20 seconds)\n2. Jumping Jacks(30 seconds)\n3. Mountain Climber (30 times)\n4. Sit Ups(14 times)\n5. Russian Twist(20 times)\n6. Plank(40 seconds)\n7. Side Bridges Right(12 times)\n8. Side Bridges Left(12 times)\n9. Crossover Crunch(12 times)\n10. Mountain Climber (28 times)\n11. Sit Ups(14 times)\n12. Russian Twist(20 times)\n13. Plank(40 seconds)\n14. Side Bridges Right(10 times)\n15. Side Bridges Left(10 times)\n16. Crossover Crunch(12 times)\n17. Side Plank Left(20 seconds)\n18. Side Plank Right(20 seconds)\n19. Cobra Stretch(30 seconds)\n20. Lying Twist Stretch Left(30 seconds)\n21. Lying Twist Stretch right(30 seconds)") 
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==20):
            print("Rest Day\n")
            xx = input("Apakah anda telah beristirahat dengan baik hari ini(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, konsisten dalam berolahraga dan berisitrahat adalah sebuah usaha yang patut diapresiasi\n")
            else:
                print("Untuk mendapatkan hasil yang maksimal, istirahat yang cukup sangat diperlukan :)")
        elif(a==21):
            print("1. High Stepping(20 seconds)\n2. Jumping Jacks(30 seconds)\n3. Abdominal Crunches(18 times)\n4. Russian Twist(22 times)\n5. Leg In & Outs(16 times)\n6. Flutter Kicks(30 seconds)\n7. Side Bridges Right(14 times)\n8. Side Bridges Left(14 times)\n9. Crossover Crunch(14 times)\n10. Abdominal Crunches(18 times)\n11.Russian Twist(22 times)\n12. Leg In & Outs(16 times)\n13. Flutter Kicks(30 seconds)\n14. Side Bridges Right(14 times)\n15. Side Bridges Left(14 times)\n16. Crossover Crunch(14 times)\n17. Crossover Crunch(12 times)\n18. Side Plank Left(20 seconds)\n19. Side Plank Right(20 seconds)\n19. Cobra Stretch(30 seconds)\n20. Lying Twist Stretch Left(30 seconds)\n21. Lying Twist Stretch right(30 seconds)") 
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==22):
            print("1. High Stepping(20 seconds)\n2. Jumping Jacks(30 seconds)\n3. Mountain Climber(30 times)\n4. 90/90 Crunch(14 times)\n5. Leg In & Outs(18 times)\n6. Plank(40 seconds)\n7. Reclined Oblique Twist(18 times)\n8. Side Bridges Left(16 times)\n9. Side Bridges Left(16 times)\n10. Mountain Climber(30 times)\n11. 90/90 Crunch(14 times)\n12. Leg In & Outs(18 times)\n13. Plank(40 seconds)\n14. Reclined Oblique Twist(18 times)\n15. Side Bridges Left(16 times)\n16. Side Bridges Left(16 times)\n17. T Plank Left(4 times)\n18. T Plank Right(4 times)\n19. Side Plank Left(20 seconds)\n20. Side Plank Right(20 seconds)\n21. Cobra Stretch(30 seconds)\n22. Lying Twist Stretch Left(30 seconds)\n23. Lying Twist Stretch right(30 seconds)") 
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==23):
            print("1. High Stepping(20 seconds)\n2. Jumping Jacks(30 seconds)\n3. Sit Ups(16 times)\n4. Russian Twist(22 times)\n5. 90/90 Crunch(16 times)\n6. Leg In & Outs(18 times)\n7. Plank(50 seconds)\n8. Flutter Kicks(30 seconds)\n9. Reclined OBlique Twist(20 times)\n10. Bicycle Crunches(14 times)\n11. Sit Ups(16 times)\n12. Russian Twist(22 times)\n13. 90/90 Crunch(16 times)\n14. Leg In & Outs(18 times)\n15. Plank(50 seconds)\n16. Flutter Kicks(30 seconds)\n17. Reclined OBlique Twist(20 times)\n18. Bicycle Crunches(14 times)\n19. Side Plank Left(20 seconds)\n20. Side Plank Right(20 seconds)\n21. Cobra Stretch(30 seconds)\n22. Lying Twist Stretch Left(30 seconds)\n23. Lying Twist Stretch right(30 seconds)") 
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==24):
            print("Rest Day\n")
            xx = input("Apakah anda telah beristirahat dengan baik hari ini(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, konsisten dalam berolahraga dan berisitrahat adalah sebuah usaha yang patut diapresiasi\n")
            else:
                print("Untuk mendapatkan hasil yang maksimal, istirahat yang cukup sangat diperlukan :)")
        elif(a==25):
            print("1. High Stepping(20 seconds)\n2. Jumping Jacks(30 seconds)\n3. Mountain Climber(32 times)\n4. Sit Ups(16 times)\n5. Abdominal Crunches(20 times)\n6. Russian Twist(24 times)\n7. Side Bridges Left(18 times)\n8. Side Bridges Right(18 times)\n9. Crossover Crunch(16 times)\n10. Mountain Climber(32 times)\n11. Sit Ups(16 times)\n12. Abdominal Crunches(20 times)\n13. Russian Twist(24 times)\n14. Side Bridges Left(16 times)\n15. Side Bridges Left(14 times)\n16. Crossover Crunch(16 times)\n17. Side Plank Left(20 seconds)\n18. Side Plank Right(20 seconds)\n19. Cobra Stretch(30 seconds)\n20. Lying Twist Stretch Left(30 seconds)\n21. Lying Twist Stretch right(30 seconds)") 
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==26):
            print("1. High Stepping(20 seconds)\n2. Jumping Jacks(30 seconds)\n3. Standing Bicycle Crunches(30 times)\n4. Abdominal Crunches(20 times)\n5. Russian Twist(24 times)\n6. 90/90 Crunch(18 times)\n7. Leg In & Outs(20 times)\n8. Plank(50 seconds)\n9. Crossover Crunch(18 times)\n10. Standing Bicycle Crunches(30 times)\n11. Abdominal Crunches(20 times)\n12. Russian Twist(24 times)\n13. 90/90 Crunch(18 times)\n14. Leg In & Outs(20 times)\n15. Plank(50 seconds)\n16. Crossover Crunch(18 times)\n17. T Plank Left(4 times)\n18. T Plank Right(4 times)\n19. Side Plank Left(30 seconds)\n20. Side Plank Right(30 seconds)\n21. Cobra Stretch(30 seconds)\n22. Lying Twist Stretch Left(30 seconds)\n23. Lying Twist Stretch right(30 seconds)") 
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==27):
            print("1. High Stepping(20 seconds)\n2. Jumping Jacks(30 seconds)\n3. Mountain Climber(32 times)\n4. Sit Ups(18 times)\n5. Russian Twist(24 times)\n6. Flutter Kicks(36 seconds)\n7. Reclined Oblique Twist(22 times)\n8. Side Bridges Left(20 times)\n9. Side Bridges Right(20 times)\n10. Bicycle Crunches(16 times)\n11. Mountain Climber(32 times)\n12. Sit Ups(18 times)\n13. Russian Twist(24 times)\n14. Flutter Kicks(36 seconds)\n15. Reclined Oblique Twist(24 times)\n16. Side Bridges Left(20 times)\n17. Side Bridges Right(20 times)\n18. Bicycle Crunches(16 times)\n19. T Plank Left(4 times)\n20. T Plank Right(4 times)\n21. Side Plank Left(30 seconds)\n22. Side Plank Right(30 seconds)\n23. Cobra Stretch(30 seconds)\n24. Lying Twist Stretch Left(30 seconds)\n25. Lying Twist Stretch right(30 seconds)") 
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==28):
            print("Rest Day\n")
            xx = input("Apakah anda telah beristirahat dengan baik hari ini(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, konsisten dalam berolahraga dan berisitrahat adalah sebuah usaha yang patut diapresiasi\n")
            else:
                print("Untuk mendapatkan hasil yang maksimal, istirahat yang cukup sangat diperlukan :)")
        elif(a==29):
            print("1. High Stepping(20 seconds)\n2. Jumping Jacks(30 seconds)\n3. Mountain Climber(32 times)\n4. Abdominal Crunches(22 times)\n5. Russian Twist(26 times)\n6. 90/90 Crunch(20 times)\n7. Leg In & Out(20 times)\n8. Plank(60 seconds)\n9. Flutter Kicks(36 seconds)\n10. Bicycle Crunches(18 times)\n11. Mountain Climber(32 times)\n12. Abdominal Crunches(22 times)\n13. Russian Twist(26 times)\n14. 90/90 Crunch(20 times)\n15. Leg In & Out(20 times)\n16. Plank(60 seconds)\n17. Flutter Kicks(36 seconds)\n18. Bicycle Crunches(18 times)\n19. T Plank Left(6 times)\n20. T Plank Right(6 times)\n21. Side Plank Left(30 seconds)\n22. Side Plank Right(30 seconds)\n23. Cobra Stretch(30 seconds)\n24. Lying Twist Stretch Left(30 seconds)\n25. Lying Twist Stretch right(30 seconds)") 
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif(a==30):
            print("1. High Stepping(20 seconds)\n2. Jumping Jacks(30 seconds)\n3. Abdominal Crunches(22 times)\n4. 90/90 Crunch(20 times)\n5. Leg In & Outs(22 times)\n6. Plank(60 seconds)\n7. Reclined Oblique Twist(22 times)\n8. Side Bridges Left(22 times)\n9. Side Bridges Right(22 times)\n10. Bicycle Crunches(16 times)\n11. Abdominal Crunches(22 times)\n12. 90/90 Crunch(20 times)\n13. Leg In & Outs(22 times)\n14. Plank(60 seconds)\n15. Reclined Oblique Twist(22 times)\n16. Side Bridges Left(22 times)\n17. Side Bridges Right(22 times)\n18. Bicycle Crunches(16 times)\n19. T Plank Left(4 times)\n20. T Plank Right(4 times)\n21. Side Plank Left(30 seconds)\n22. Side Plank Right(30 seconds)\n23. Cobra Stretch(30 seconds)\n24. Lying Twist Stretch Left(30 seconds)\n25. Lying Twist Stretch right(30 seconds)") 
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
                print("\nSelamat, anda telah menyelesaikan program 30 hari untuk membakar lemak perut\n")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
                print("\nSelamat, anda telah menyelesaikan program 30 hari untuk membakar lemak perut\n")
        else:
            print("OUT OF RANGE!!")
        yy = str(input("\nApakah anda ingin melanjutkan lagi(Yes/No)\t: "))
        if (yy == "Yes" or yy=="YES" or yy=="yes"):
            continue
        elif(yy == "No" or yy=="no" or yy=="NO"):
            break
        else:
            break

def Program3():
    print("Fat Burning HIIT (2-7 menit)")
    print("Istirahat 10 detik di setiap pergantian gerakan")
    print("1. HIIT 2 Menit\n2. HIIT 5 Menit\n3. HIIT 7 Menit\n")
    yy = "Yes"
    while(yy=="Yes" or yy=="YES" or yy=="yes"):
        a = int(input("Kategori Waktu Workout(Menit)\t: "))
        if (a==1):
            print("1. Star Jumps\t\t: (20 seconds)\n2. Flutter Kicks\t: (20 seconds)\n3. Heel Touch\t\t: (20 seconds)\n4. In & Outs\t\t: (20 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif (a==2):
            print("1. Burpees\t\t\t: (20 seconds)\n2. Skipping Without Rope\t: (20 seconds)\n3. Abdominal Crunches\t\t: (20 seconds)\n4. Plank Jacks\t\t\t: (20 seconds)\n5. Up And Down Plank\t\t: (20 seconds)\n6. Jumping Squats\t\t: (20 seconds)\n7. Flutter Kicks\t\t: (20 seconds)\n8. Modified Burpees\t\t: (20 seconds)\n9. High Stepping\t\t: (20 seconds)\n10. Pendulum Swings\t\t: (20 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif (a==3):
            print("1. High Stepping\t: (20 seconds)\n2. Squats\t\t: (20 seconds)\n3. Squat Jacks\t\t: (20 seconds)\n4. In & Outs\t\t: (20 seconds)\n5. Mountain Climber\t: (20 seconds)\n6. Body Saw\t\t: (20 seconds)\n7.Burpees\t\t: (20 seconds)\n8. Butt Kicks\t\t: (20 seconds)\n9. Russian Twist\t: (20 seconds)\n10. Abdominal Crunches\t: (20 seconds)\n11. Knee Push Ups\t: (20 seconds)\n12. X Burpees\t\t: (20 seconds)\n13. Side Hop\t\t: (20 seconds)\n14. Backward Lunge\t: (20 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        else:
            print("OUT OF RANGE!!")
        yy = str(input("\nApakah anda ingin melanjutkan lagi(Yes/No)\t: "))
        if (yy == "Yes" or yy=="YES" or yy=="yes"):
            continue
        elif(yy == "No" or yy=="no" or yy=="NO"):
            break
        else:
            break

def Program4():
    print("Office Workout (2-7 menit)")
    print("Istirahat 10 detik di setiap pergantian gerakan")
    print("1. Office Workout 2 Menit\n2. Office Workout 5 Menit\n3. Office Workout 7 Menit\n")
    yy = "Yes"
    while(yy=="Yes" or yy=="YES" or yy=="yes"):
        a = int(input("Kategori Waktu Workout(Menit)\t: "))
        if (a==1):
            print("1. Lunges\t\t\t\t: (20 seconds)\n2. Side Bend Reach Right\t\t: (20 seconds)\n3. Clockwise Shoulder Rolls\t\t: (20 seconds)\n4. Seated Hamstring Stretch Right\t: (20 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif (a==2):
            print("1. Seated Hamstring Stretch Left\t: (20 seconds)\n2. Clockwise Shoulder Rolls\t\t: (20 seconds)\n3. Incline Push Ups\t\t\t: (20 seconds)\n4. Clasp Hands Behind Back\t\t: (20 seconds)\n5. Side Neck Stretch Right\t\t: (20 seconds)\n6. Right Leg Lateral Raise\t\t: (20 seconds)\n7. Side Bend Reach Right\t\t: (20 seconds)\n8. Lunges\t\t\t\t: (20 seconds)\n9. Levator Scapule Stretch Right\t: (20 seconds)\n10. Triceps Dips\t\t\t: (20 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif (a==3):
            print("1. Triceps Stretch Left\t\t\t: (20 seconds)\n2. Lunges\t\t\t\t: (20 seconds)\n3. Clasp Hands Behind Back\t\t: (20 seconds)\n4. Shoulder Stretch With Chair\t\t: (20 seconds)\n5. Triceps Stretch Right\t\t: (20 seconds)\n6. Left Leg Lateral Raise\t\t: (20 seconds)\n7. Knee To Blow Crunches\t\t: (20 seconds)\n8. Side Neck Stretch Right\t\t: (20 seconds)\n9. Backward Lunge\t\t\t: (20 seconds)\n10. Sumo Squat\t\t\t\t: (20 seconds)\n11. Calf Raise With Splayed Foot\t: (20 seconds)\n12. Seated Hamstring Stretch Left\t: (20 seconds)\n13. Side Neck Stretch Left\t\t: (20 seconds)\n14. Chair Squats\t\t\t: (20 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        else:
            print("OUT OF RANGE!!")
        yy = str(input("\nApakah anda ingin melanjutkan lagi(Yes/No)\t: "))
        if (yy == "Yes" or yy=="YES" or yy=="yes"):
            continue
        elif(yy == "No" or yy=="no" or yy=="NO"):
            break
        else:
            break


def Program5():
    print("Bed Workout (2-7 menit)")
    print("Istirahat 10 detik di setiap pergantian gerakan")
    print("1. Bed Workout 2 Menit\n2. Bed Workout 5 Menit\n3. Bed Workout 7 Menit\n")
    yy = "Yes"
    while(yy=="Yes" or yy=="YES" or yy=="yes"):
        a = int(input("Kategori Waktu Workout(Menit)\t: "))
        if (a==1):
            print("1. Bottom Leg Lift Right\t: (20 seconds)\n2. Bridge\t\t\t: (20 seconds)\n3. Hip Bridge & Leg Lift Left\t: (20 seconds)\n4. V Hold\t\t\t: (20 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif (a==2):
            print("1. Hip Bridge & Leg Lift Right\t\t\t: (20 seconds)\n2. Glute Stertch Left\t\t\t: (20 seconds)\n3. Bridge\t\t\t\t: (20 seconds)\n4. V Hold\t\t\t\t: (20 seconds)\n5. Oblique Crossover Crunch Left\t: (20 seconds)\n6. V Crunch\t\t\t\t: (20 seconds)\n7. Bird Dog\t\t\t\t: (20 seconds)\n8. Pilates Clamshell Left\t\t: (20 seconds)\n9. Crossarm Crunches\t\t\t: (20 seconds)\n10. Superman\t\t\t\t: (20 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif (a==3):
            print("1. Crunch Kicks\t\t\t\t: (20 seconds)\n2. Cat Cow Pose\t\t\t\t: (20 seconds)\n3. V Crunch\t\t\t\t: (20 seconds)\n4. Floor Y Raises\t\t\t: (20 seconds)\n5. Bent Leg Twist\t\t\t: (20 seconds)\n6. Oblique Crossover Crunch Left\t: (20 seconds)\n7. Oblique Crossover Crunch Right\t: (20 seconds)\n8. Pilates Clamshell Right\t\t: (20 seconds)\n9. Superman\t\t\t\t: (20 seconds)\n10. Double Knees To Chest\t\t: (20 seconds)\n11. Toe Tap\t\t\t\t: (20 seconds)\n12. Seated Side bend Right\t\t: (20 seconds)\n13. Side Leg Circles Right\t\t: (20 seconds)\n14. Froggy Glute Lifts\t\t\t: (20 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        else:
            print("OUT OF RANGE!!")
        yy = str(input("\nApakah anda ingin melanjutkan lagi(Yes/No)\t: "))
        if (yy == "Yes" or yy=="YES" or yy=="yes"):
            continue
        elif(yy == "No" or yy=="no" or yy=="NO"):
            break
        else:
            break


def Program6():
    print("Flat Belly (2 menit)")
    print("Istirahat 10 detik di setiap pergantian gerakan")
    print("1. Flat Belly Beginner\n2. Flat Belly Intermediate\n3. Flat Belly Advanced\n")
    yy = "Yes"
    while(yy=="Yes" or yy=="YES" or yy=="yes"):
        a = int(input("Kategori Workout\t: "))
        if (a==1):
            print("1. Standing bicycle Crunches\t: (20 seconds)\n2. Leg Raises\t\t\t: (20 seconds)\n3. Bent Leg Twist\t\t: (20 seconds)\n4. Mountain Climber\t\t: (20 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif (a==2):
            print("1. Leg Raises\t\t\t: (20 seconds)\n2. Abdominal Crunches\t\t: (20 seconds)\n3. Reclined Oblique Twist\t: (20 seconds)\n4. Flutter Kicks\t\t: (20 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif (a==3):
            print("1. Knee To Blow Crunches\t: (20 seconds)\n2. X Man Crunch\t\t\t: (20 seconds)\n3. Plank Hip Dips\t\t: (20 seconds)\n4. Leg Raises\t\t\t: (20 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        else:
            print("OUT OF RANGE!!")
        yy = str(input("\nApakah anda ingin melanjutkan lagi(Yes/No)\t: "))
        if (yy == "Yes" or yy=="YES" or yy=="yes"):
            continue
        elif(yy == "No" or yy=="no" or yy=="NO"):
            break
        else:
            break

def Program7():
    print("Angel Booty (2 menit)")
    print("Istirahat 10 detik di setiap pergantian gerakan")
    print("1. Angel Booty Beginner\n2. Angel Booty Intermediate\n3. Angel Booty Advanced\n")
    yy = "Yes"
    while(yy=="Yes" or yy=="YES" or yy=="yes"):
        a = int(input("Kategori Workout\t: "))
        if (a==1):
            print("1. Butt Kicks\t\t: (20 seconds)\n2. Donkey Kicks Left\t: (20 seconds)\n3. Donkey Kicks Right\t: (20 seconds)\n4. Backward Lunge\t: (20 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif (a==2):
            print("1. Side Lunges\t\t: (20 seconds)\n2. Fire Hydrant Right\t: (20 seconds)\n3. Fire Hydrant Left\t: (20 seconds)\n4. Plie Squats\t\t: (20 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif (a==3):
            print("1. Squats\t\t\t\t\t: (20 seconds)\n2. Squat Pulses\t\t\t\t: (20 seconds)\n3. Glute Kickback Crossover With Right Leg\t: (20 seconds)\n4. Glute Kickback Crossover With Left Leg\t: (20 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        else:
            print("OUT OF RANGE!!")
        yy = str(input("\nApakah anda ingin melanjutkan lagi(Yes/No)\t: "))
        if (yy == "Yes" or yy=="YES" or yy=="yes"):
            continue
        elif(yy == "No" or yy=="no" or yy=="NO"):
            break
        else:
            break

def Program8():
    print("Toned Arms(2 menit)")
    print("Istirahat 10 detik di setiap pergantian gerakan")
    print("1. Toned Arms Beginner\n2. Toned Arms Intermediate\n3. Toned Arms Advanced\n")
    yy = "Yes"
    while(yy=="Yes" or yy=="YES" or yy=="yes"):
        a = int(input("Kategori Workout\t: "))
        if (a==1):
            print("1. Chest Press Pulse\t: (20 seconds)\n2. Triceps Dips\t\t: (20 seconds)\n3. Wall Push Ups\t: (20 seconds)\n4. Inchworms\t\t: (20 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif (a==2):
            print("1. Back Bow Pulls\t: (20 seconds)\n2. Knee Push Ups\t: (20 seconds)\n3. Up and Down Plank\t: (20 seconds)\n4. Inchworms\t\t: (20 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif (a==3):
            print("1. Havyk Raises\t\t: (20 seconds)\n2. Bent Over Row\t: (20 seconds)\n3. Dumbbell Chest Fly\t: (20 seconds)\n4. Modified Burpees\t: (20 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        else:
            print("OUT OF RANGE!!")
        yy = str(input("\nApakah anda ingin melanjutkan lagi(Yes/No)\t: "))
        if (yy == "Yes" or yy=="YES" or yy=="yes"):
            continue
        elif(yy == "No" or yy=="no" or yy=="NO"):
            break
        else:
            break


def Program9():
    print("Slim Legs (2 menit)")
    print("Istirahat 10 detik di setiap pergantian gerakan")
    print("1. Slim Legs Beginner\n2. Slim Legs Intermediate\n3. Slim Legs Advanced\n")
    yy = "Yes"
    while(yy=="Yes" or yy=="YES" or yy=="yes"):
        a = int(input("Kategori Workout\t: "))
        if (a==1):
            print("1. Side Lunges\t\t\t: (20 seconds)\n2. Frog Press\t\t\t: (20 seconds)\n3. Bottom Leg Lift Left\t\t: (20 seconds)\n4. Bottom Leg Lift Right\t: (20 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif (a==2):
            print("1. Plank leg Up\t\t: (20 seconds)\n2. Leg Spreads\t\t: (20 seconds)\n3. Side Leg Circles Left\t: (20 seconds)\n4. Side Leg Circles Right\t: (20 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        elif (a==3):
            print("1. Plank Jacks\t\t\t: (20 seconds)\n2. Air Cycling\t\t\t: (20 seconds)\n3. Straight Leg Fire Hydrant Left\t: (20 seconds)\n4. Straight Leg Fire Hydrant Right\t: (20 seconds)\n")
            xx = input("\nApakah anda berhasil menyelesaikan program latihan hari ini dengan baik(Yes/No)\t: ")
            if (xx == "Yes"):
                print("Selamat, anda telah menyelesaikan program latihan hari ini")
            else:
                print("Tetap semangat dan jangan menyerah, anda bisa mencoba lagi besok :)")
        else:
            print("OUT OF RANGE!!")
        yy = str(input("\nApakah anda ingin melanjutkan lagi(Yes/No)\t: "))
        if (yy == "Yes" or yy=="YES" or yy=="yes"):
            continue
        elif(yy == "No" or yy=="no" or yy=="NO"):
            break
        else:
            break


def Program10():
    print("Program Wajah Tirus (3 menit)")
    print("Istirahat 10 detik di setiap pergantian gerakan\n")
    yy = "No"
    while(yy == "No" or yy=="no" or yy=="NO"):
        print("1. AEIOU(30 seconds)\n2. Counterlockwise Circles(30 seconds)\n3. Smiling Fish Face(30 Seconds)\n4. Cheek Firmer(30 seconds)\n5. Marilyn(30 Seconds)\n6. Puffy Cheeks(30 Seconds)\n")
        yy = str(input("\nApakah anda ingin mengganti program latihan(Yes/No)\t: "))
        if (yy == "No" or yy=="no" or yy=="NO"):
            continue
        elif(yy == "Yes" or yy=="YES" or yy=="yes"):
            break
        else:
            break

def Program11():
    print("Program Double Chin (3 menit)")
    print("Istirahat 10 detik di setiap pergantian gerakan\n")
    yy = "No"
    while(yy == "No" or yy=="no" or yy=="NO"):
        print("1. Nose Touching(30 seconds)\n2. Drawn Cheeks(30 seconds)\n3. Puffy Cheeks(30 seconds)\n4. Underchin Duck(30 seconds)\n5. Smile(30 seconds)\n6. Neck Lift(30 seconds)\n")
        yy = str(input("\nApakah anda ingin mengganti program latihan(Yes/No)\t: "))
        if (yy == "No" or yy=="no" or yy=="NO"):
            continue
        elif(yy == "Yes" or yy=="YES" or yy=="yes"):
            break
        else:
            break


def A():
    print("\nSelamat datang di sesi konsultasi 'Asupan Makanan'. Dalam sesi konsultasi ini anda akan diberikan saran mengenai sumber, cara penyajian, jadwal, dan jumlah makanan yang akan anda konsumsi setiap harinya agar sesuai dengan takaran yang tentunya sesuai dengan pola hidup sehat.")
    print("\nKategori Budget dalam sekali makan:\n1. Kurang dari 20K\n2. Lebih dari 20K")
    aa = int(input("\nMasukkan nomor kategori budget yang anda miliki dalam sekali makan\t: "))
    print("\nSUMBER")
    if(aa==1):
        print("Saran makanan pada kategori 1:\n1. Karbohidrat\t: beras putih, singkong, ubi jalar, dll.\n2. Protein\t: Tahu, telur, tempe, ayam, ikan, dll.\n3. Sayuran\t: kangkung, kol, wortel, selada, kucai, genjer, dll.\n4. Buah-buahan\t: Pisang, tomat, timun, jeruk, pepaya, nanas, mangga, dll.")
    elif(aa==2):
        print("Semua jenis makanan pada kategori 1:\n1. Karbohidrat\t: beras putih, singkong, ubi jalar, dll.\n2. Protein\t: Tahu, telur, tempe, ayam, ikan, dll.\n3. Sayuran\t: kangkung, kol, wortel, selada, kucai, genjer, dll.\n4. Buah-buahan\t: Pisang, tomat, timun, jeruk, pepaya, nanas, mangga, dll.")
        print("\nSaran makanan pada kategori 2:\n1. Karbohidrat\t: Beras merah, beras coklat, beras basmati, kentang, jagung, oat, quinoa, dll. \n2. Protein\t: Sapi, burung, kerang, dll.\n3. Sayuran\t: Kale, brokoli, bunga kol, parsley, asparagus, dll.\n4. Buah-buahan\t: Buah naga, Berry, kiwi, apel, anggur, dll.")
    else:
        print("OUT OF RANGE!!")
    print("\nPENYAJIAN")
    print("Saran penyajian\t: Dikukus, dipanggang, direbus, digoreng(menggunakan air fryer)")
    print("Memakan makanan yang digoreng menggunakan minyak sangat tidak dianjurkan untuk orang-orang yang sedang dalam proses diet, karena minyak memiliki kandungan lemak dan kolesterol yang sangat tinggi.")
    print("Penyajian secara mentah tidak dianjurkan, karena dapat mengakibatkan berbagai macam penyakit.")
    print("\nJADWAL")
    print("Mengatur jadwal makan merupakan hal yang penting. Berikut saran jadwal makan:\n1. Makan pagi\t: Sebelum beraktifitas & sebelum jam 9 pagi.\n2. Makan siang\t: 11.00 - 13.00\n3. Makan sore\t: 17.00 - 18.00")
    print("Dengan jadwal makan seperti ini, tubuh tidak akan menerima makanan minimal selama 12 jam, tentunya ini hampir sama dengan berpuasa. Sehingga akan memberikan efek positif yang baik dalam proses diet.")
    print("\nJUMLAH")
    print("Kami akan menyediakan jumlah karbohidrat, protein, serat, dan air yang anda butuhkan setiap harinya. Oleh karena itu, kami membutuhkan informasi frekuensi aktifitas olahraga anda.")
    print("\nSkor tingkat aktivitas olahraga:\n1. Sangat Jarang Olahraga\t: 1,2.\n2. Olahraga 1-2 kali seminggu\t: 1,375.\n3. Olahraga 3-4 kali seminggu\t: 1,55.\n4. Olahraga 5-6 kali seminggu\t: 1,725.\n5. Olahraga 2 kali sehari\t: 1,9")
    h = float(input("\nMasukkan skor tingkat aktivitas olahraga\t: "))
    if(b=="L"):
        i = float((13.4*c + 88.4) + (4.8*d) - (5.68*a))
        j = float(i*h) #Kalori
        k = float(0.1*j/4) #Protein minimal(gram)
        kk = float(0.1*j) #Protein minimal(kkal)
        l = float(0.15*j/4) #Protein maximal(gram)
        ll = float(0.15*j) #Protein maximal(kkal)
        m = float(0.6*j/4) #Karbohidrat minimal(gram)
        mm = float(0.6*j) #Karbohidrat minimal(Kkal)
        n = float(0.75*j/4) #Karbohidrat Maximal(gram)
        nn = float(0.75*j) #Karbohidrat Maximal(kkal)
        o = float(0.1*j/9) #Lemak minimal(gram)
        oo = float(0.1*j) #Lemak minimal(kkal)
        p = float(0.25*j/9) #Lemak maksimal(gram)
        pp = float(0.25*j) #Lemak maksimal(kkal)
        q = float(0.014*j) #Serat
        r = float(((c-20)*20)+1500)
        print("Estimasi energi yang anda habiskan dalam 1 hari\t: {:.2f} kkal\n".format(j))
        print("Berikut adalah rincian asupan yang anda butuhkan dalam 1 hari:\n1. Protein\t: {:.2f} - {:.2f} gram atau {:.2f} - {:.2f} kkal.\n2. Karbohidrat\t: {:.2f} - {:.2f} gram atau {:.2f} - {:.2f} kkal.\n3. Lemak\t: {:.2f} - {:.2f} gram atau {:.2f} - {:.2f} kkal.\n4. Serat\t: {:.2f} gram\n5. Air\t\t: {:.2f} ml" .format(k, l, kk, ll, m, n, mm, nn, o, p, oo, pp, q, r))
        print("\nSeluruh informasi diatas kami hitung berdasarkan informasi usia, massa tubuh, tinggi, dan skor aktivitias olahraga yang telah anda berikan sebelumnya")
    elif(b=="P"):
        i = float((9.25*c + 447.6) + (3.1*d) - (4.33*a))
        j = float(i*h) #Kalori
        k = float(0.1*j/4) #Protein minimal(gram)
        kk = float(0.1*j) #Protein minimal(kkal)
        l = float(0.15*j/4) #Protein maximal(gram)
        ll = float(0.15*j) #Protein maximal(kkal)
        m = float(0.6*j/4) #Karbohidrat minimal(gram)
        mm = float(0.6*j) #Karbohidrat minimal(Kkal)
        n = float(0.75*j/4) #Karbohidrat Maximal(gram)
        nn = float(0.75*j) #Karbohidrat Maximal(kkal)
        o = float(0.1*j/9) #Lemak minimal(gram)
        oo = float(0.1*j) #Lemak minimal(kkal)
        p = float(0.25*j/9) #Lemak maksimal(gram)
        pp = float(0.25*j) #Lemak maksimal(kkal)
        q = float(0.014*j) #Serat
        r = float(((c-20)*20)+1500)
        print("Estimasi energi yang anda habiskan dalam 1 hari\t: {:.2f} kkal\n".format(j))
        print("Berikut adalah rincian asupan yang anda butuhkan dalam 1 hari:\n1. Protein\t: {:.2f} - {:.2f} gram atau {:.2f} - {:.2f} kkal.\n2. Karbohidrat\t: {:.2f} - {:.2f} gram atau {:.2f} - {:.2f} kkal.\n3. Lemak\t: {:.2f} - {:.2f} gram atau {:.2f} - {:.2f} kkal.\n4. Serat\t: {:.2f} gram\n5. Air\t\t: {:.2f} ml" .format(k, l, kk, ll, m, n, mm, nn, o, p, oo, pp, q, r))
        print("\nSeluruh informasi diatas kami hitung berdasarkan informasi usia, massa tubuh, tinggi, dan skor aktivitias olahraga yang telah anda berikan sebelumnya")
    else:
        print("OUT OF RANGE!!")
    print("\nUntuk bisa mengurangi berat badan secara teratur dengan diet, anda bisa melakukan hal-hal berikut ini:\n1. Menjaga asupan gula, maksimal 50 gram setiap harinya\n2. Menjaga asupan garam, maksimal 2400 mg setiap harinya\n3. Minum air sesuai dengan kebutuhan\n4. Melakukan defisit kalori. Memastikan asupan yang kita makan sesuai dengan takaran gizi yang cukup dan jumlah kalori kurang dari kebutuhan tubuh.")
    print("\nKami berharap sesi konsultasi ini dapat membantu anda untuk meningkatkan kualitas asupan tubuh anda untuk kedepannya.\n")


def BMI():
    print("\nIMT\t\t: Indeks Massa Tubuh")
    print("IMT<18,5\t: Berat badan kurang")
    print("18,5<=IMT<=22,9\t: Berat badan normal")
    print("23<=IMT<=29,9\t: Berat badan berlebih (kecenderungan obesitas)")
    print("IMT>=30\t\t: Obesitas\n")
    a = (d/100)**2
    b = c/a
    if (b<18.5):
        print("Kategori Berat Badan Anda\t: Berat badan kurang\n")
    elif (b>=18.5 and b<=22.9):
        print("Kategori Berat Badan Anda\t: Berat badan normal\n")
    elif (b>=23 and b<=29.9):
        print("Kategori Berat Badan Anda\t: Berat badan berlebih\n")
    elif (b>30):
        print("Kategori Berat Badan Anda\t: Obesitas\n")
    else:
        print("Out of range\n")
    

def Tidur():
    print("\nSelamat datang di sesi konsultasi 'tidur'. Dalam sesi konsultasi ini, anda akan diberikan informasi mengenai mengenai larangan-larangan sebelum tidur, lama waktu tidur yang baik, manfaat tidur malam, dan manfaat tidur siang.")
    print("\nSilahkan isi beberapa pertanyaan dibawah ini, agar kami dapat memberikan saran yang tepat.")
    a = float(input("\nBerapa lama waktu yang anda butuhkan untuk tidur dalam sehari(jam)\t: "))
    if(a>=6 and a<9):
        print("Waktu tidur anda masih masuk dalam kategori cukup")
    elif(a<6):
        print("Waktu tidur anda terlalu sedikit, hal ini bisa berdampak pada sel-sel tubuh, tekanan darah, dan fungsi otak.")
    elif(a>=9 and a<=24):
        print("Waktu tidur anda lebih dari yang seharusnya, segera konsultasikan ini pada dokter. Kemungkinan anda mengalami masalah pada gula darah anda")
    else:
        print("Anda sedang tidak sadar atau mengalami koma")
    b = float(input("\nSeberapa sering anda begadang dalam seminggu\t\t\t\t: "))
    if(b>=2):
        print("Anda berpotensi mendapatkan berbagai masalah pada tubuh anda")
    else:
        print("Kualitas tidur anda masih dalam tingkat yang baik")
    c = str(input("\nApakah anda memiliki gangguan tidur(Yes/No)\t\t\t\t: "))
    if(c=="Yes"):
        print("Anda bisa mengikuti saran-saran dibawah ini agar dapat tidur lebih nyenyak\n")
    else:
        print("Anda bisa mengikuti saran-saran dibawah ini agar dapat tidur lebih nyenyak\n")
    print("Larangan-larangan sebelum tidur:\n1. Makan dan minum terlalu banyak\n2. Olahraga berat\n3. Minum kafein\n4. Menonton tv dan menggunakan gadget")
    print("\nManfaat tidur malam:\n1. Menjaga jantung\n2. Mencegah penyakit kanker\n3. Mengurangi stress\n4. Mengurangi peradangan\n5. Meningkatkan kualitas ingatan\n6. Membantu mengurangi berat badan\n7. Meningkat fungsi kognitif otak\n8. Membantu tubuh dalam meperbaiki sel-sel yang rusak\n9. Mencegah kerusakan terjadi pada otak")
    print("\nManfaat tidur siang:\n1. Memperbaiki konsentrasi\n2. Memperbaiki suasana hati\n3. Menurunkan tekanan darah")
    print("\nWaktu yang dibutuhkan setiap orang untuk tidur itu berbeda-beda. Hal itu tergantung dari gen, usia, dan gaya hidup. Namun, ada penelitian yang membuktikan bahwa tidur kurang dari 6 jam saat malam hari dapat berdampak pada sel-sel metabolisme, gen, dan kekebalan.")
    print("\nSalah satu pola tidur yang paling banyak dianjurkan adalah pola tidur bifasik. Pola tidur ini membagi jumlah waktu tidur menjadi 2 kali. Seperti contoh berikut:\n1. Tidur 7 jam sehari\t: 6 jam saat malam dan 1 jam saat siang\n2. Tidur 8 jam sehari\t: 7 jam saat malam dan 1 jam saat siang\nPola tidur bifasik terbukti memiliki manfaat untuk meningkatkan daya konsentrasi dan energi tubuh serta membantu menjaga kadar gula darah.")
    print("\nKami berharap sesi konsultasi tidur ini dapat memberikan anda beberapa pengetahuan baru mengenai tidur sehingga anda bisa tidur lebih nyenyak kedepannya.\n")


def Program_Olahraga():
    print("Selamat datang di sesi konsultasi program olahraga. Kami menyediakan berbagai pilihan program latihan sesuai dengan hasil yang anda inginkan dan waktu yang anda miliki.")
    print("Workout adalah cara tercepat untuk membakar gula yang ada didalam tubuh kita sebelum disimpan menjadi lemak. Oleh karena itu, melakukan workout minimal selama 2-7 menit perhari akan membantu menjaga kadar lemak didalam tubuh kita sehingga berdampak pada massa tubuh")
    print("Pilihan Program:\n1. Lose Weight & Still Fit (30 days)\n2. Lost Belly Fat (30 days)\n3. Fat Burning HIIT (2-7 menit)\n4. Office Workout (2-7 menit)\n5. Bed Workout (2-7 menit)\n6. Flat Belly (2 menit)\n7. Angel Booty (2 menit)\n8. Toned Arms (2 menit)\n9. Slim Legs (2 menit)\n10. Program Wajah Tirus (3 menit)\n11. Program Double Chin (3 menit)\n")
    c = "Yes"
    while(c == "Yes" or c=="YES" or c=="yes"):
        b = int(input("Nomor kategori program\t: ")) 
        if (b==1):
            Program1()
        elif(b==2):
            Program2()
        elif(b==3):
            Program3()
        elif(b==4):
            Program4()
        elif(b==5):
            Program5()
        elif(b==6):
            Program6()
        elif(b==7):
            Program7()
        elif(b==8):
            Program8()
        elif(b==9):
            Program9()
        elif(b==10):
            Program10()
        elif(b==11):
            Program11()
        else:
            print("OUT OF NUMBER!!")
        c = str(input("\nApakah anda ingin mengulang memilih jenis program latihan(Yes/No)\t: "))  
        if(c == "Yes" or c=="yes" or c=="YES"):
            continue
        elif(c == "No" or c=="no" or c=="NO"):
            break
        else:
            print("Jawaban tidak sesuai\n")
            break  


print("\nKONSULTASI POLA HIDUP SEHAT\n")
print("Untuk mendapatkan tubuh yang sehat, dibutuhkan pola hidup yang sehat pula. Didalam pola hidup sehat, ada 3 hal utama yang harus diatur dengan baik. 3 hal itu adalah:")
print("1. Asupan Tubuh\n2. Pola Olahraga\n3. Pola Tidur\n")
f = str(input("\nApakah anda ingin melakukan konsultasi(Yes/No)\t: "))
print("\nSilahkan isi beberapa pertanyaan dibawah ini, jawaban atas pertanyaan dibawah ini akan mempengaruhi hasil konsultasi pada 3 hal utama yang telah disebutkan sebelumnya.")
b = str(input("\nJenis kelamin anda(L/P)\t\t\t: "))
a = int(input("Umur anda(tahun)\t\t\t: "))
c = float(input("Massa anda(KG)\t\t\t\t: "))
d = float(input("Tinggi anda(CM)\t\t\t\t: "))
while (f=="Yes" or f=="YES" or f=="yes"):
    e = int(input("\nMasukkan nomor kategori yang anda ingin konsultasikan\t: "))
    if (e==1):
        A()
    elif(e==2):
        BMI()
        Program_Olahraga()
    elif(e==3):
        Tidur()
    else:
        print("OUT OF RANGE!!")
    f = str(input("Apakah anda ingin melanjutkan konsultasi(Yes/No)\t: "))
    if (f=="Yes" or f=="yes" or f=="YES"):
        continue
    elif(f=="No" or f=="no" or f=="NO"):
        break
print("\nTerima kasih telah menggunakan jasa kami\n")


# print("\nRENCANA HIDUP SEHAT\n")
# print("1. Makanan dan Kebutuhan Tubuh\n2. Pola Olahraga\n3. Pola Tidur\n")
# a = int(input("Umur anda(tahun)\t\t\t: "))
# b = str(input("Jenis kelamin anda(L/P)\t\t\t: "))
# c = float(input("Massa anda(KG)\t\t\t\t: "))
# d = float(input("Tinggi anda(CM)\t\t\t\t: "))
# print("\n")
# while (True):
#     e = int(input("Masukkan nomor kategori yang anda inginkan\t: "))
#     if (e==1):
#         A()
#     elif(e==2):
#         BMI()
#     elif(e==3):
#         Tidur()
#     else:
#         print("OUT OF RANGE!!!")
#     f = str(input("Apakah anda ingin melanjutkan konsultasi(Yes/No)\t: "))
#     if (f=="Yes"):
#         continue
#     elif(f=="No"):
#         break
# print("\nTerima kasih telah menggunakan jasa kami\n")


